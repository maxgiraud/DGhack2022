<?php

include_once "config.php";
include_once "vendor/autoload.php";

function download()
{
    $zipfile = __DIR__ . "/app.zip";
    if (file_exists($zipfile)) {
        header("Content-type: application/zip");
        header('Content-Disposition: attachment; filename=' . basename($zipfile));
        header("Content-Length: " . filesize($zipfile));
        header("Pragma: no-cache");
        header("Expires: 0");
        flush();
        readfile($zipfile);
        die();
    }
    return "L'archive des sources n'existe pas." . PHP_EOL;
}

function main()
{
    $message = "";
    if (isset($_REQUEST["data"])) {
        try {
            $decoded = base64_decode($_REQUEST["data"]);
            $data = unserialize($decoded);
        } catch (\Throwable $t) {
            var_dump($t);
        }
    } else {
        $message = "<p>Des hackers ont pu accéder à la configuration de tout notre système via notre serveur web.</p>" . PHP_EOL .
            "<p>Decouvrez comment ils ont pu y accéder en auditant les sources du site.</p>" . PHP_EOL .
            "<p>Vous pouvez télécharger les sources en <a href='?download=1'>cliquant ici !</a></p>" . PHP_EOL .
            "<p>N.B: la configuration du système se trouve dans le fichier config.php.<p>" . PHP_EOL;
    }
    return $message;
}

function display()
{
    if (isset($_REQUEST['download'])) {
        $message = download();
    } else {
        $message = main();
    }
    return $message;
}

?>