<?php

include_once "functions.php";

$title = "A really secured Company";
$message = display();

?>

<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title><?php echo $title; ?></title>

        <!-- CSS files -->
        <link href="static/css/bootstrap/bootstrap.css" rel="stylesheet">
        <link href="static/css/bootstrap/font/bootstrap-icons.css" rel="stylesheet">
        <link href="static/css/index.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top justify-content-between">
            <div>
                <a class="navbar-brand" href="/"><?php echo $title; ?></a>
                <a class="navbar-brand" href="#Menu">Menu</a>
                <a class="navbar-brand" href="#About">About</a>
                <a class="navbar-brand" href="#Posts">Posts</a>
                <a class="navbar-brand" href="#Shop">Shop</a>
                <a class="navbar-brand" href="#Contact">Contact</a>
            </div>
        </nav>
        <div class="main">
            <div class="icon">
                <i class="bi bi-exclamation-circle" style="font-size: 5rem; color: grey;"></i>
            </div>
            <div class="message">
                <?php echo $message; ?>
            </div>
        </div>

    </body>
</html>